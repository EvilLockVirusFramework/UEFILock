// data.h
// Auto-generated: embedded BOOTX64.EFI from C:\edk2\release\BOOTX64.EFI
#pragma once

#include <cstddef>
#include <cstdint>

extern const std::uint8_t kEmbeddedBootx64Efi[];
extern const std::size_t kEmbeddedBootx64EfiSize;